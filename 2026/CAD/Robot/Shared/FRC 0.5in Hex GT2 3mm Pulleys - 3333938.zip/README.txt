FRC 0.5in Hex GT2 3mm Pulleys by Maximillian on Thingiverse: https://www.thingiverse.com/thing:3333938

Summary:
A variety of 1/2 Hex GT2 pulleys. Tolerance of hex calibrated for Prusa i3 MK3 to be a tight slip fit. 