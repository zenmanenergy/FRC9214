HTD Parametric Pulley Used in FRC by OceanHikerMike on Thingiverse: https://www.thingiverse.com/thing:5206075

Summary:
Solidworks 2021 Universal HTD pulley with VersaKey and Lightening pocket options.Requires 2 inputs from use:INPUT_teeth_numberINPUT_pulley_width (9 or 15mm)Manually Unsuppress / Suppress:VersaKeyLightening Pockets4419 worked hard on the model so please give some love. Thank You!!